<?php
/**
*
* This file is part of the phpBBex.
*
* @copyright (c) phpBBex <http://phpbbex.com>
* @license GNU General Public License, version 2 (GPL-2.0)
*
*/

namespace phpBBex\phpBBext;

/**
* Main extension class for this extension.
*/
class ext extends \phpbb\extension\base
{
}
